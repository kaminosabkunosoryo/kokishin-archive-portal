# Kokishin Archive Portal

This repository hosts a simple static site (GitHub Pages) for the Kokishin Archive.

## Publish on GitHub Pages
1. Create a new repo on your account **kaminosabakunosoryo** called **kokishin-archive-portal**.
2. Upload all files from this folder to the repo root (or `git push`).
3. In **Settings → Pages**, set:
   - **Source:** Deploy from a branch
   - **Branch:** `main` (or `master`) and folder `/ (root)`
4. Save. Your site will be available at: **https://kaminosabakunosoryo.github.io/kokishin-archive-portal/**

## Push via Git (optional)
```bash
git init
git branch -M main
git add .
git commit -m "Initial commit: Kokishin Archive Portal"
git remote add origin https://github.com/kaminosabakunosoryo/kokishin-archive-portal.git
# or: git@github.com:kaminosabakunosoryo/kokishin-archive-portal.git
git push -u origin main
```

## Update workflow
- Add/replace PDFs (e.g., Master Index) and commit — the site updates automatically.
- Put scroll PDFs under `/scrolls/` and add links in `index.html` when needed.
